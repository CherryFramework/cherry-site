<?php
/**
 * Silence is golden.
 *
 * @package    Blank_Plugin
 * @subpackage index
 * @author     Cherry Team
 * @license    GPL-3.0+
 * @copyright  2002-2016, Cherry Team
 */

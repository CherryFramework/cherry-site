<?php
 /*
 Plugin Name: Cherry Get Cherry
 Description: Gets latest Cherry V themes from templatemonster.com and store them like projects posts.
 Author: Cherry Team
 Version: 1.0
 License: GPL2
 Text Domain: cherry-get-cherry
 Domain Path: languages/
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( ! class_exists( 'Cherry_Get_Cherry' ) ) {

	/**
	 * Define Cherry_Get_Cherry class
	 */
	class Cherry_Get_Cherry {

		/**
		 * A reference to an instance of this class.
		 *
		 * @since 1.0.0
		 * @var   object
		 */
		private static $instance = null;

		/**
		 * API enpoint URL
		 *
		 * @var string
		 */
		private $api = 'http://api2.templatemonster.com/v2/templates.list.json';

		/**
		 * API user name for auth
		 *
		 * @var string
		 */
		private $api_user = 'cherry';

		/**
		 * API token name for auth
		 *
		 * @var string
		 */
		private $api_token = 'F70F271D6E2169A86FAB61E7ED7FDED456D5D9A0';

		/**
		 * Themes number for single step
		 *
		 * @var integer
		 */
		private $step = 2;

		/**
		 * API token name for auth
		 *
		 * @var int
		 */
		private $api_property = 227448;

		/**
		 * Constructor for the class
		 */
		function __construct() {

			if ( isset( $_GET['cherry-action'] ) && 'themes-waterfall' === $_GET['cherry-action'] ) {
				add_action( 'init', array( $this, 'waterfall_themes_list' ) );
			}

			add_action( 'after_setup_theme', array( $this, 'init_sheduled_update' ) );

		}

		/**
		 * Register shedule action for themes list update.
		 *
		 * @return void
		 */
		public function init_sheduled_update() {

			$timestamp = wp_next_scheduled( 'cherry_get_latest_themes' );

			if ( false === $timestamp ) {
				wp_schedule_event( time(), 'daily', 'cherry_get_latest_themes' );
			}

			add_action( 'cherry_get_latest_themes', array( $this, 'get_latest_themes' ) );

		}

		/**
		 * Get latest themes callback
		 *
		 * @return void
		 */
		public function get_latest_themes() {

			$received_themes = get_option( 'cherry_received_themes', 0 );
			$themes          = $this->get_themes_list( 0, 5 );

			$recived_now = 0;

			foreach ( $themes as $theme ) {
				if ( $this->fetch_theme( $theme ) ) {
					$recived_now ++;
				}
			}

			$new_count = $received_themes + $recived_now;

			update_option( 'cherry_received_themes', $new_count );

		}

		/**
		 * Convert themes to projects
		 */
		public function waterfall_themes_list() {

			$received_themes = get_option( 'cherry_received_themes', 0 );
			$themes          = $this->get_themes_list( $received_themes, $this->step );

			if ( empty( $themes ) ) {
				return;
			}

			$recived_now = 0;

			foreach ( $themes as $theme ) {
				if ( $this->fetch_theme( $theme ) ) {
					$recived_now ++;
				}
			}

			$new_count = $received_themes + $recived_now;

			if ( 0 === $received_themes && 0 !== $new_count ) {
				add_option( 'cherry_received_themes', $new_count, '', 'no' );
			} elseif ( 0 !== $new_count ) {
				update_option( 'cherry_received_themes', $new_count );
			}

			wp_die(
				sprintf( 'Was themes - %d, recieved - %d, now - %d', $received_themes, $recived_now, $new_count ),
				sprintf( '%d themes recieved', $recived_now )
			);

		}

		/**
		 * Convert single theme object.
		 *
		 * @param  array $theme Theme data to fetch.
		 * @return void
		 */
		private function fetch_theme( $theme ) {

			if ( $this->theme_exist( $theme['id'] ) ) {
				return false;
			}

			$title = $this->get_property( 'Name of the template', $theme );

			$recieved_data = array(
				'post_content'   => html_entity_decode( $this->get_property( 'Short description', $theme ) ),
				'post_excerpt'   => html_entity_decode( $this->get_property( 'Kind of shops', $theme ) ),
				'post_name'      => $theme['id'],
				'post_title'     => ( ! $title ) ? html_entity_decode( $theme['id'] ) : html_entity_decode( $title ),
			);

			$static_data = array(
				'post_status' => 'publish',
				'post_type'   => 'projects',
			);

			$meta_data = array(
				'meta_input' => $this->get_theme_meta( $theme ),
			);

			$post_data = array_merge( $static_data, $recieved_data, $meta_data );

			$post_id = wp_insert_post( $post_data );

			$category = ! empty( $theme['categories'] ) ? $theme['categories']['category0']['category_name'] : false;

			if ( $category ) {
				$this->add_categories( $post_id, html_entity_decode( $category ) );
			}

			if ( ! is_wp_error( $post_id ) ) {
				return true;
			} else {
				return false;
			}

		}

		/**
		 * Add ctegories to post
		 *
		 * @param int    $post_id  Post ID.
		 * @param string $category Category name to add.
		 */
		public function add_categories( $post_id, $category ) {

			$tax  = 'projects_category';
			$term = term_exists( $category, $tax );

			if ( ! $term ) {
				$term = wp_insert_term( $category, $tax );
				if ( is_wp_error( $term ) ) {
					return false;
				}
			}

			$term_id = $term['term_id'];

			wp_set_post_terms( $post_id, array( $term_id ), $tax );

		}

		/**
		 * Check if current theme exists in projects.
		 *
		 * @param  string $slug Theme slug.
		 * @return bool
		 */
		private function theme_exist( $slug ) {

			global $wpdb;

			$query = "SELECT ID FROM {$wpdb->posts} WHERE post_name = %s AND post_type = %s";
			$id    = $wpdb->get_var( $wpdb->prepare( $query, $slug, 'projects' ) );

			if ( $id ) {
				return true;
			} else {
				return false;
			}

		}

		/**
		 * Get theme metadata array to paste
		 *
		 * @param  array $theme Theme data.
		 * @return array
		 */
		private function get_theme_meta( $theme ) {

			$meta = array(
				'cherry_projects_external_link'      => $theme[ 'url' ],
				'cherry_projects_external_link_text' => 'View Theme',
				'cherry_projects_details'            => $this->get_theme_details( $theme ),
				'_thumbnail_id'                      => $this->fetch_theme_thumb( $theme ),
				'cherry_projects_features_screens'   => $this->get_features_screens( $theme ),
			);

			return $meta;
		}

		/**
		 * Get array with theme details.
		 *
		 * @param  array $theme Theme data.
		 * @return array
		 */
		private function get_theme_details( $theme ) {

			$details = array(
				'Additional Features',
				'Animation',
				'Coding',
				'Features',
				'Functionality',
				'Gallery Script',
				'Web Forms',
			);

			$result = array();
			$i      = 0;

			foreach ( $details as $property ) {

				$value = $this->get_property( $property, $theme, false );
				$value = is_array( $value ) ? $value : array();

				$result[ 'item-' . $i ] = array(
					'detail_label' => $property,
					'detail_info'  => implode( ', ', $value ),
				);

				$i++;
			}

			return $result;
		}

		/**
		 * Get theme features screens array
		 *
		 * @param  array $theme Theme data.
		 * @return array
		 */
		private function get_features_screens( $theme ) {

			$result = array();

			foreach ( $theme['screenshots_list'] as $screen ) {

				if ( false !== strpos( $screen['uri'], '-en_' ) ) {
					$result[] = esc_url( $screen['uri'] );
				}

			}

			return $result;

		}

		/**
		 * Get theme metadata array to paste
		 *
		 * @param  array $theme Theme data.
		 * @return array
		 */
		private function fetch_theme_thumb( $theme ) {

			$url = false;

			foreach ( $theme['screenshots_list'] as $screen ) {

				if ( false !== strpos( $screen['uri'], '-original-1200.jpg' ) ) {
					$url = esc_url( $screen['uri'] );
					break;
				}

			}

			if ( ! $url ) {
				return false;
			}

			ini_set( 'max_execution_time', 300 );
			set_time_limit( 0 );

			$upload = $this->fetch_remote_file( $url );

			if ( is_wp_error( $upload ) ) {
				return $upload;
			}

			$info = wp_check_filetype( $upload['file'] );

			if ( ! $info ) {
				return new WP_Error( 'attachment_processing_error', 'Invalid file type' );
			}

			$post = array(
				'post_mime_type' => $info['type'],
				'guid'           => $upload['url'],
				'post_title'     => $theme['id'] . '-thumbnail',
			);

			$post_id = wp_insert_attachment( $post, $upload['file'] );

			if ( is_wp_error( $post_id ) ) {
				return $post_id;
			}

			ini_set( 'max_execution_time', 300 );
			set_time_limit( 0 );

			if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) {
				require str_replace( get_bloginfo( 'url' ) . '/', ABSPATH, get_admin_url() ) . 'includes/image.php';
			}

			$data = wp_generate_attachment_metadata( $post_id, $upload['file'] );
			wp_update_attachment_metadata( $post_id, $data );

			return $post_id;
		}

		/**
		 * Attempt to download a remote file attachment
		 *
		 * @param  string $url  URL of item to fetch.
		 * @return array|WP_Error Local file location details on success, WP_Error otherwise.
		 */
		protected function fetch_remote_file( $url ) {

			// extract the file name and extension from the url
			$file_name = basename( $url );

			// get placeholder file in the upload dir with a unique, sanitized filename
			$upload = wp_upload_bits( $file_name, 0, '' );
			if ( $upload['error'] ) {
				return new WP_Error( 'upload_dir_error', $upload['error'] );
			}

			// fetch the remote url and write it to the placeholder file
			$response = wp_remote_get( $url, array(
				'timeout'  => 30,
				'stream'   => true,
				'filename' => $upload['file']
			) );

			// request failed
			if ( is_wp_error( $response ) ) {
				@unlink( $upload['file'] );
				return $response;
			}

			$code = (int) wp_remote_retrieve_response_code( $response );

			// make sure the fetch was successful
			if ( $code !== 200 ) {
				@unlink( $upload['file'] );
				return new WP_Error(
					'import_file_error',
					sprintf(
						'Remote server returned %1$d %2$s for %3$s',
						$code,
						get_status_header_desc( $code ),
						$url
					)
				);
			}

			$filesize = filesize( $upload['file'] );

			if ( 0 == $filesize ) {
				@unlink( $upload['file'] );
				return new WP_Error( 'import_file_error', 'Zero size file downloaded' );
			}

			return $upload;
		}

		/**
		 * Recursiv get value from nested arrays
		 *
		 * @param  string $keys   Property name to search.
		 * @param  array  $theme  Theme data array.
		 * @param  bool   $single Retrun only first property value or all values.
		 * @return mixed
		 */
		private function get_property( $name = '', $theme = array(), $single = true ) {

			foreach ( $theme['properties'] as $property ) {

				if ( ! isset( $property['propertyName'] ) || $name !== $property['propertyName'] ) {
					continue;
				}

				if ( $single ) {
					return $property['propertyValues']['propertyValue0'];
				} else {
					return $property['propertyValues'];
				}
			}

			return false;
		}

		/**
		 * Remote get themes list.
		 *
		 * @return array
		 */
		private function get_themes_list( $start = 0, $count = 10 ) {

			$args = array(
				'user'       => $this->api_user,
				'token'      => $this->api_token,
				'properties' => $this->api_property,
				'start'      => $start,
				'count'      => $count,
			);

			$url      = add_query_arg( $args, $this->api );
			$response = wp_remote_get( $url );
			$body     = wp_remote_retrieve_body( $response );

			if ( ! $body ) {
				return array();
			}

			$result = json_decode( $body, true );

			if ( ! isset( $result['result'] ) ) {
				return array();
			}

			return $result['result'];
		}

		/**
		 * Returns the instance.
		 *
		 * @since  1.0.0
		 * @return object
		 */
		public static function get_instance() {

			// If the single instance hasn't been set, set it now.
			if ( null == self::$instance ) {
				self::$instance = new self;
			}
			return self::$instance;
		}
	}

}

/**
 * Returns instance of Cherry_Get_Cherry
 *
 * @return object
 */
function cgc() {
	return Cherry_Get_Cherry::get_instance();
}

cgc();
